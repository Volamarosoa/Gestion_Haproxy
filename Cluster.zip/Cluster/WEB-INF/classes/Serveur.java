package serveur;

import dao.generiqueDAO.GeneriqueDAO;
import dao.annotations.Table;

import java.util.List;

import dao.annotations.Colonne;
import dao.annotations.PrimaryKey;

import etu2068.modelView.ModelView;
import etu2068.annotations.Url;

@Table
public class Serveur extends GeneriqueDAO{
    @PrimaryKey
    @Colonne
    int id = -1;
    @Colonne
    String ip;
    @Colonne
    String nom;
    @Colonne
    int etat = -1;

    public Serveur() {}

    public Serveur(String ip, String nom) {
        this.setId(id);
        this.setNom(nom);
    }

    public Serveur(String ip) {
        this.setId(id);
    }

    public Serveur(int etat) {
        this.setEtat(etat);
    }

    public int getId() {
        return this.id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public void setId(String id) {
        this.id = Integer.valueOf(id);
    }

    public String getIp() {
        return this.ip;
    }
    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getNom() {
        return this.nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getEtat() {
        return this.etat;
    }
    public void setEtat(int etat) {
        this.etat = etat;
    }
    public void setEtat(String etat) {
        this.etat = Integer.valueOf(etat);
    }

    @Url(name = "/ajout_nouveau_serveur")
    public ModelView inserer() throws Exception {
        ModelView view = new ModelView("insertion_Serveur.jsp");
        return view;
    }

    @Url(name = "/enregistrer")
    public ModelView save() throws Exception {
        this.setEtat(10);
        this.insert(null);
        ModelView view = new ModelView("insertion_Serveur.jsp");
        return view;
    }

    @Url(name = "/listeServeur")
    public ModelView listeDesServeur() throws Exception {
        ModelView view = new ModelView("liste_Serveur.jsp");
        this.setEtat(10);
        view.addItem("liste", (List<Serveur>) this.list(null));
        return view;
    }

    @Url(name = "/deleteServeur")
    public ModelView deleteServeur() throws Exception {
        this.setEtat(5);
        this.updateById(null, "" + this.getId());
        ModelView view = new ModelView("liste_Serveur.jsp");
        view.addItem("liste", (List<Serveur>) new Serveur(10).list(null));
        return view;
    }

    @Url(name = "/updateServeur")
    public ModelView updateServeur() throws Exception {
        this.updateById(null, "" + this.getId());
        ModelView view = new ModelView("liste_Serveur.jsp");
        view.addItem("liste", (List<Serveur>) new Serveur(10).list(null));
        return view;
    }

    @Url(name = "/modifier")
    public ModelView ModifierServeur() throws Exception {
        ModelView view = new ModelView("update.jsp");
        view.addItem("serveur", ((List<Serveur>) this.list(null)).get(0));
        return view;
    }


}