create database cluster;
\c cluster;

create table serveur (
    id serial,
    ip varchar(20),
    nom varchar(20),
    etat int
);